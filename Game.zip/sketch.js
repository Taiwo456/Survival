let player;
let cliffs = [];
let health = 100;
let score = 0;
let gameState = "mainMenu";
let playerName = "";
let highScores = [];
let playerSpeed = 2;
let jumpStrength = 12;
let gravity = 0.4;
let gap = 80;
let speed = 1.5;
let isJumping = false;
let gameStarted = false;
let scoringEnabled = false;
let lastScoreUpdate = 0;
let stars = [];

function setup() {
  createCanvas(800, 400);
  createUI();
  generateInitialCliffs();
  generateStars();
}

function draw() {
  drawBackground();

  if (gameState === "mainMenu") {
    showMainMenu();
  } else if (gameState === "getPlayerName") {
    getPlayerName();
  } else if (gameState === "playing") {
    playGame();
  } else if (gameState === "leaderboard") {
    showLeaderboard();
  } else if (gameState === "gameOver") {
    displayGameOver();
  }
}

function createUI() {
  input = createInput();
  input.position(300, 220);
  input.hide();

  submitButton = createButton('Submit');
  submitButton.position(300, 250);
  submitButton.mousePressed(startGameWithPlayerName);
  submitButton.hide();

  backButton = createButton('Back');
  backButton.position(20, 20);
  backButton.mousePressed(() => {
    gameState = "mainMenu";
    input.hide();
    submitButton.hide();
    backButton.hide();
  });
  backButton.hide();

  startButton = createButton('Start Game');
  startButton.position(width / 2 - 50, height / 2 + 30);
  startButton.mousePressed(() => {
    gameState = "getPlayerName";
    startButton.hide();
  });
}

function showMainMenu() {
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(32);
  text("Main Menu", width / 2, height / 2 - 50);
  textSize(20);
  text("Press 'Start Game' to play or 'L' to view Leaderboard", width / 2, height / 2);
  startButton.show();

  if (keyIsPressed && (key === 'L' || key === 'l')) {
    gameState = "leaderboard";
    backButton.show();
    startButton.hide();
  }
}

function getPlayerName() {
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(20);
  text("Enter your name to start:", width / 2, height / 2 - 50);
  input.show();
  submitButton.show();
}

function startGameWithPlayerName() {
  playerName = input.value();
  if (playerName.trim() !== "") {
    gameState = "playing";
    initializeGame();
    input.hide();
    submitButton.hide();
  }
}

function playGame() {
  fill(255);
  textSize(16);
  text(`Score: ${score}`, 20, 20);
  text(`Health: ${health}`, 20, 40);

  handleInput();
  if (gameStarted) {
    updateCliffs();
    updateScore();
    increaseGapAndSpeedBasedOnScore();
  }
  player.update();
  player.show();

  if (player.y > height) {
    gameState = "gameOver";
    updateLeaderboard();
    backButton.show();
  }
}

function updateLeaderboard() {
  const existingPlayer = highScores.find(entry => entry.name === playerName);
  if (existingPlayer) {
    if (score > existingPlayer.score) {
      existingPlayer.score = score;
    }
  } else {
    highScores.push({ name: playerName, score: score });
  }
  highScores.sort((a, b) => b.score - a.score);
  highScores = highScores.slice(0, 5); // Keep top 5 scores
}

function updateScore() {
  if (frameCount - lastScoreUpdate >= 60 && scoringEnabled) {
    score += 5;
    lastScoreUpdate = frameCount;
  }
}

function handleInput() {
  if (keyIsDown(LEFT_ARROW) && player.x > 0) {
    player.move(-playerSpeed);
    startGameMovement();
  }
  if (keyIsDown(RIGHT_ARROW) && player.x < width) {
    player.move(playerSpeed);
    startGameMovement();
  }
  if (keyIsDown(32) && !isJumping) {
    player.jump();
    isJumping = true;
    startGameMovement();
  }
}

function startGameMovement() {
  if (!gameStarted) {
    gameStarted = true;
    scoringEnabled = true;
  }
}

function generateInitialCliffs() {
  cliffs = [];
  let xPos = 150;
  while (xPos < width + 200) {
    let cliff = { x: xPos, y: random(180, 250), w: random(100, 140), h: 50 };
    cliffs.push(cliff);
    xPos += cliff.w + gap;
  }
}

function updateCliffs() {
  for (let i = cliffs.length - 1; i >= 0; i--) {
    let cliff = cliffs[i];
    cliff.x -= speed;

    fill(90, 50, 100);
    rect(cliff.x, cliff.y, cliff.w, cliff.h);

    if (cliff.x + cliff.w < 0) {
      cliffs.splice(i, 1);
      cliffs.push({ x: width + gap, y: random(180, 250), w: random(100, 140), h: 50 });
    }
  }
}

function displayGameOver() {
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(32);
  text("Game Over", width / 2, height / 2 - 20);
  textSize(20);
  text(`Final Score: ${score}`, width / 2, height / 2 + 20);
}

function showLeaderboard() {
  background(30, 20, 50);
  drawBackground();
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(32);
  text("Leaderboard", width / 2, 50);

  textSize(20);
  for (let i = 0; i < highScores.length && i < 5; i++) {
    text(`${highScores[i].name}: ${highScores[i].score}`, width / 2, 100 + i * 30);
  }

  backButton.show();
}

function increaseGapAndSpeedBasedOnScore() {
  if (score >= 140 && score < 200) {
    gap = 100;
    speed = 1.7;
    playerSpeed = 2.2;
  } else if (score >= 200 && score < 250) {
    gap = 120;
    speed = 1.9;
    playerSpeed = 2.4;
  } else if (score >= 250 && score < 300) {
    gap = 140;
    speed = 2.1;
    playerSpeed = 2.6;
  } else if (score >= 300 && score < 350) {
    gap = 160;
    speed = 2.3;
    playerSpeed = 2.8;
  } else if (score >= 350) {
    gap = 180;
    speed = 2.5;
    playerSpeed = 3.0;
  }
}

function initializeGame() {
  player = new Player(cliffs[0].x + cliffs[0].w / 2, cliffs[0].y - 10);
  health = 100;
  score = 0;
  gameStarted = false;
  scoringEnabled = false;
  lastScoreUpdate = frameCount;
}

function generateStars() {
  for (let i = 0; i < 50; i++) {
    stars.push({
      x: random(width),
      y: random(height / 2),
      size: random(1, 3)
    });
  }
}

function drawBackground() {
  background(30, 20, 50);
  
  fill(240, 240, 200);
  ellipse(width - 100, 100, 80, 80);

  fill(255);
  for (let star of stars) {
    ellipse(star.x, star.y, star.size, star.size);
  }
}

class Player {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.yVelocity = 0;
    this.onGround = true;
  }

  show() {
    fill(100, 150, 255);
    ellipse(this.x, this.y, 20, 20);
  }

  move(dx) {
    this.x += dx;
  }

  jump() {
    if (this.onGround) {
      this.yVelocity = -jumpStrength;
      this.onGround = false;
    }
  }

  update() {
    this.yVelocity += gravity;
    this.y += this.yVelocity;

    for (let i = 0; i < cliffs.length; i++) {
      let cliff = cliffs[i];
      if (
        this.x > cliff.x && this.x < cliff.x + cliff.w &&
        this.y + 10 > cliff.y && this.y < cliff.y + cliff.h
      ) {
        this.y = cliff.y - 10;
        this.yVelocity = 0;
        this.onGround = true;
        isJumping = false;
        break;
      } else {
        this.onGround = false;
      }
    }
  }
}
