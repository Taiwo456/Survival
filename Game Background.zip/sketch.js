let cliffs = [];
let speed = 3;
let gap = 100; 

function setup() {
  createCanvas(800, 400);
  generateInitialCliffs();
}

function draw() {
  background(30, 20, 50);
  
  // Draw the moon
  noStroke();
  fill(200, 200, 255, 200);
  ellipse(600, 100, 100, 100); 

  // Draw the ground
  fill(60, 30, 70);
  rect(0, 300, width, 100); 

  // Update and draw the cliffs
  updateCliffs();
  drawStars();
}

function generateInitialCliffs() {
  // Create initial set of cliffs with varying heights at ground level
  let xPos = 150;
  while (xPos < width + 200) {
    let cliff = {
      x: xPos,
      y: random(180, 250), 
      w: random(80, 120), 
      h: 50 
    };
    cliffs.push(cliff);
    xPos += cliff.w + gap; 
  }
}

function updateCliffs() {
  // Move each cliff to the left to create a scrolling effect
  for (let i = cliffs.length - 1; i >= 0; i--) {
    let cliff = cliffs[i];
    cliff.x -= speed;

    // Draw the cliff
    fill(90, 50, 100);
    rect(cliff.x, cliff.y, cliff.w, cliff.h);

    // Remove cliffs that have moved off-screen and generate new ones
    if (cliff.x + cliff.w < 0) {
      cliffs.splice(i, 1);

      // Generate a new cliff at the end of the canvas with a fixed gap and varying height
      let newCliff = {
        x: width + gap,
        y: random(180, 250),
        w: random(80, 120),
        h: 50
      };
      cliffs.push(newCliff);
    }
  }
}

function drawStars() {
  noStroke();
  fill(255, 255, 255);
  for (let i = 0; i < 50; i++) {
    ellipse(random(width), random(height / 2), 2, 2);
  }
}







